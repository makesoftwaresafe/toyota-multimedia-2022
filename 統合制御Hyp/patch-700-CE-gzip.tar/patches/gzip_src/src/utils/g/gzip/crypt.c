/* crypt.c (dummy version) -- do not perform encryption
 * Hardly worth copyrighting :-)
 */
#ifdef RCSID
static char rcsid[] = "$Id: crypt.c 171047 2008-06-20 13:42:23Z rmansfield $";
#endif
typedef int dummy;
